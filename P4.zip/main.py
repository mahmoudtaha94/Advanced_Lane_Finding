#import numpy as np
#import cv2
#import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from step1 import calibrate,undistort
from step2 import getChannel,getGradient,applyBinary,combineAND,combineOR,stack2Channels
from step3 import changePerspective
from step4 import curverad,curverad2ndFrame

mtx,dist=calibrate()
img=mpimg.imread('./test_images/straight_lines1.jpg')
undistorted=undistort(img,mtx,dist)
#cv2.imwrite('./output_images/distorted.jpg',undistorted)
L=getChannel(img,mode='HLS',channel='L')
gradient=getGradient(L,mode='x')
binary=applyBinary(gradient,thresh=(20,100))

S=getChannel(img,mode='HLS',channel='S')
sbinary=applyBinary(S,thresh=(170,255))
#rr=stack2Channels(binary,sbinary)
rr=combineOR(binary,sbinary)
#plt.imshow(img)
src=np.float32(
            [[600,450],
             [288,666],
             [1030,666],
             [688,450]])

warped=changePerspective(rr,src)
curverad(warped,warped.shape[0],450)

mpimg.imsave('./output_images/rr.png',rr,cmap='gray')
mpimg.imsave('./output_images/b.png',binary,cmap='gray')
mpimg.imsave('./output_images/sb.png',sbinary,cmap='gray')
mpimg.imsave('./output_images/warped.png',warped,cmap='gray')
