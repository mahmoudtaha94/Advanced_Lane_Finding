from moviepy.editor import VideoFileClip

from step1 import calibrate,undistort
from step2 import getChannel,getGradient,applyBinary,combineAND,combineOR,stack2Channels
from step3 import changePerspective
from step4 import findLanes,drawLanes
from step5 import curverad,centerDiff
from step6 import writeOnFrame
'''
calibrate once
'''
mtx,dist=calibrate()

def pipeline(img):
    '''
    undistort images
    '''
    img=undistort(img,mtx,dist)
    
    '''
    preprocess Images
    '''
    gray=getChannel(img,mode='gray',channel=None)
    gradx=getGradient(gray,mode='x',sobel_kernel=3)
    gradx=applyBinary(gradx,thresh=(12,255))
    
    grady=getGradient(gray,mode='y',sobel_kernel=3)
    grady=applyBinary(grady,thresh=(25,255))
    
    S=getChannel(img,mode='HLS',channel='S')
    sbinary=applyBinary(S,thresh=(100,255))
    
    V=getChannel(img,mode='HSV',channel='V')
    vbinary=applyBinary(V,thresh=(50,255))
    
    colorBinary=combineAND(vbinary,sbinary)
    
    preprocessedImage=combineAND(gradx,grady)
    preprocessedImage=combineOR(preprocessedImage,colorBinary)
    preprocessedImage[preprocessedImage==1]=255
    '''
    work on changing prespective 
    '''
    trapizoid_pct={}
    trapizoid_pct['mid_width']=0.08
    trapizoid_pct['height_pct']=0.62
    trapizoid_pct['bot_width']=0.76
    trapizoid_pct['bottom_trim']=0.935
    warped=changePerspective(preprocessedImage,trapizoid_pct,0.25,inverse=False)
    '''
    find the lanes
    '''
    result,leftx,rightx,midx,curve_centers=findLanes(warped,window_width=25,My_ym=10/720, My_xm=4/384,window_height=80)
    '''
    draw the lanes on the video frames
    '''
    result,res_yvals,yvals,left_fitx,right_fitx=drawLanes(img,warped,result,leftx,rightx,midx,trapizoid_pct,window_width=25,window_height=80)
    '''
    calculate the curvature radius in meters based on a new line in the middle of the lane (brown)
    '''
    curve_rad=curverad(curve_centers,res_yvals,yvals,midx)
    '''
    calculate the difference from the center of the lane
    '''
    center_diff,side_pos=centerDiff(warped,left_fitx,right_fitx,curve_centers.xm_per_pix)
    '''
    write the curvature radius and center difference on the video frames
    '''
    writeOnFrame(result,curve_rad,center_diff,side_pos)
    return result
    
clip1=VideoFileClip('project_video.mp4')
video_clip=clip1.fl_image(pipeline)
video_clip.write_videofile('project_video_output.mp4',audio=False)














