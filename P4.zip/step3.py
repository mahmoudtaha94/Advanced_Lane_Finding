import numpy as np
import cv2
'''
this file is step 3 (change perspective):
1- change perspective
'''
def changePerspective(img,src,offset=100,inverse=False):
    #src= 4 source points from the original image
    if len(src)<4:
        print('Error: changePerspective needs atleast 4 source points')
        exit()
    img_size=(img.shape[1],img.shape[0])
    print(img.shape[1],img.shape[0])
    dst = np.float32([[offset, offset],
                      [ offset,img_size[0]-offset], 
                      [ img_size[1]-offset,img_size[0]-offset], 
                      [ img_size[1]-offset,offset]])
    
    # Warp the image using OpenCV warpPerspective()
    if inverse:
        M = cv2.getPerspectiveTransform(dst, src)
    else:
        M = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(img, M, img_size)
    return warped